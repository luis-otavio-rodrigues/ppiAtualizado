-- SunSafe - migração para quem JÁ importou o sunsafe.sql
USE sunsafe;

ALTER TABLE usuarios
  ADD COLUMN idade TINYINT UNSIGNED DEFAULT NULL AFTER tipo,
  ADD COLUMN cidade VARCHAR(120) DEFAULT NULL AFTER idade;
